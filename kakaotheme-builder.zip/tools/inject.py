#!/usr/bin/env python3
# theme_input/(KakaoTalkTheme.css + 이미지) → src/main/theme/ 에 색·이미지 주입
import os, sys
HERE=os.path.dirname(os.path.abspath(__file__)); REPO=os.path.dirname(HERE)
sys.path.insert(0, HERE)
import ktheme2android as K
from PIL import Image

ios=os.path.join(REPO,"theme_input")
scale=int(os.environ.get("SCALE","3"))

# theme_input 에 css 있나?
has_css=any(f.lower()=="kakaotalktheme.css" for _,_,fs in os.walk(ios) for f in fs)
if not has_css:
    print("※ theme_input 에 KakaoTalkTheme.css 가 없어요 → 기본 어피치 그대로 빌드합니다.")
    sys.exit(0)

css_text, images_dir = K.resolve_ios(ios, "/tmp/ktwork")
css=K.parse_css(css_text)
tb=css.get("TabBarStyle-Main",{})
for a,b in [("-ios-now-normal-icon-image","-ios-view-normal-icon-image"),
            ("-ios-now-selected-icon-image","-ios-view-selected-icon-image")]:
    if not tb.get(a) and tb.get(b): tb[a]=tb[b]

res=K.build_colors(css); colors=res[0] if isinstance(res,tuple) else res
K.write_colors_xml(colors, os.path.join(REPO,"src/main/theme/values/colors.xml"))
print("■ 색상", len(colors), "개 주입")

draw=os.path.join(REPO,"src/main/theme/drawable-xxhdpi"); os.makedirs(draw,exist_ok=True)
done=nine=0; miss=[]
for andfn,(sel,prop,mode) in K.IMAGE_RULES.items():
    iosfn,cx,cy=K.parse_img(css.get(sel,{}).get(prop,""))
    if not iosfn: miss.append(andfn); continue
    src=K.find_image(images_dir, iosfn, scale)
    if not src: miss.append(andfn); continue
    dst=os.path.join(draw,andfn)
    if mode=="ninepatch": K.make_ninepatch(src,dst,cx,cy,scale); nine+=1
    else: Image.open(src).convert("RGBA").save(dst)
    done+=1
print(f"■ 이미지 {done}개 주입 (나인패치 {nine}), 누락 {len(miss)}")
print("■ 테마:", css.get("ManifestStyle",{}).get("-kakaotalk-theme-name"))
